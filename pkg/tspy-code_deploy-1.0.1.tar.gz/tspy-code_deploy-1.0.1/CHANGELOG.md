# Change Log

## [1.0.0] First attempt at converting Nate's Purge Node task(2018-01-31)

* Initial release
